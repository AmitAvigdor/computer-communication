﻿using CoffeeShop.Context;
using CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeShop.Controllers
{
    public class ItemsController : Controller
    {
        private readonly ILogger<ItemsController> _logger;
        private readonly DBContext _dbContext;

        public ItemsController(ILogger<ItemsController> logger, DBContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Index()
        {
            List<Item> items;
            try
            {
                //pulled out from the database all the items by category
                items = await _dbContext.Items.Include(x => x.Category).ToListAsync();
            }
            catch 
            {
                items = new List<Item>();
            }

            return View(items);
        }
        //creating or editing an item using the item id, if null we'll create if not null we'll edit 
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddOrEdit(long? itemId)
        {
            try
            {
                ViewBag.PageName = itemId == null ? "Create Item" : "Edit Item";
                ViewBag.IsEdit = itemId == null ? false : true;

                var categories = await _dbContext.ItemCategories.ToListAsync();

                List<SelectListItem> categoriesLst = new List<SelectListItem>();

                foreach (var item in categories)
                {
                    categoriesLst.Add(new SelectListItem
                    {
                        Text = item.Name,
                        Value = item.Id.ToString(),
                        Selected = false
                    });
                }

                ViewBag.data = categoriesLst;
                //is available? if true it will show on the menu else no
                List<SelectListItem> lst = new List<SelectListItem>()
                {
                    new SelectListItem{ Text = "True", Value = "True", Selected  = false},
                    new SelectListItem{ Text = "False", Value = "False", Selected  = false}
                };

                ViewBag.lst = lst;
                //checks if there is an item id if not return view else we will find it in the data base
                if (itemId == null)
                {
                    return View();
                }
                else
                {
                    var item = await _dbContext.Items.Where(x => x.Id == itemId)
                                                     .Include(x => x.Category)
                                                     .SingleOrDefaultAsync();
                    //if also didnt found we'll return to the idex page
                    if (item == null)
                    {
                        return View("Index", "Items");
                    }

                    ViewBag.selected = item.Category.Id;
                    ViewBag.isAvailable = item.IsAvailable;

                    return View(item);
                }
            }
            catch
            {
                return View("Index", "Items");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(Item itemData)
        {
            try
            {
                string categoryIdForm = Request.Form["categoriesLst"].ToString();
                string isAvailableForm = Request.Form["Lst"].ToString();
                long categoryId;
                bool isAvailable;

                if (string.IsNullOrWhiteSpace(categoryIdForm))
                {
                    ViewBag.Message = "Category isn't valid";
                    return await AddOrEdit(itemData.Id);
                }

                if (!long.TryParse(categoryIdForm, out categoryId))
                {
                    ViewBag.Message = "Category isn't valid";
                    return await AddOrEdit(itemData.Id);
                }

                if (!bool.TryParse(isAvailableForm, out isAvailable))
                {
                    ViewBag.Message = "isAvailable isn't valid";
                    return await AddOrEdit(itemData.Id);
                }

                ItemCategory category = await _dbContext.ItemCategories.Where(x => x.Id == categoryId).SingleOrDefaultAsync();

                if (category == null)
                {
                    ViewBag.Message = "Category doesn't exist";
                    return await AddOrEdit(itemData.Id);
                }

                Item currentItem = await _dbContext.Items.Where(x => x.Id == itemData.Id).SingleOrDefaultAsync();

                if (ModelState.IsValid)
                {
                    if (currentItem != null)
                    {
                        currentItem.Name = itemData.Name;
                        currentItem.Price = itemData.Price;
                        currentItem.Description = itemData.Description;
                        currentItem.Image = itemData.Image;
                        currentItem.Category = category;
                        currentItem.IsAvailable = isAvailable;

                        _dbContext.Update(currentItem);
                    }
                    else
                    {
                        Item item = new Item(itemData.Name, category, itemData.Price, itemData.Description, itemData.Image, isAvailable);
                        _dbContext.Items.Add(item);
                    }

                    await _dbContext.SaveChangesAsync();

                    return RedirectToAction("Index", "Items");
                }
                else
                {
                    ViewBag.Message = "Form isn't valid";
                    return await AddOrEdit(itemData.Id);
                }
            }
            catch
            {
                ViewBag.Message = "DB Error";
                return await AddOrEdit(itemData.Id);
            }
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(long itemId)
        {
            try
            {
                var item = await _dbContext.Items.Where(x => x.Id == itemId).SingleOrDefaultAsync();

                if (item != null)
                {
                    _dbContext.Items.Remove(item);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch
            {

            }

            return RedirectToAction("Index", "Items");
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Details(long itemId)
        {
            try
            {
                var item = await _dbContext.Items.Where(x => x.Id == itemId).Include(x => x.Category).SingleOrDefaultAsync();

                if (item != null)
                {
                    return View(item);
                }
            }
            catch
            {

            }

            return RedirectToAction("Index", "Items");
        }
    }
}
