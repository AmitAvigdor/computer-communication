﻿using CoffeeShop.Context;
using CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeShop.Controllers
{
    public class MenuController : Controller
    {
        private readonly DBContext _dbContext;

        public MenuController(DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> Index()
        {
            List<Item> menuItems;
            try
            {
                menuItems = await _dbContext.Items.Where(x => x.IsAvailable).Include(x => x.Category).ToListAsync();
            }
            catch
            {
                menuItems = new List<Item>();
            }
            return View(menuItems);
        }
    }
}
