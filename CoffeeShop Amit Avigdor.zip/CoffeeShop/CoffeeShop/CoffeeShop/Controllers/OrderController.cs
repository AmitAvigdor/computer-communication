﻿using CoffeeShop.Context;
using CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeShop.Controllers
{
    public class OrderController : Controller
    {
        private readonly DBContext _dbContext;

        public OrderController(DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> Index()
        {
            List<Order> orders;
            try
            {
                var userId = User.Claims.ToList().Where(x => x.Type == "userId").Select(x => x.Value).SingleOrDefault();
                orders = await _dbContext.Orders.Where(x => x.User.Id == long.Parse(userId))
                                                 .Include(x => x.User)
                                                 .ToListAsync();
            }
            catch
            {
                orders = new List<Order>();
            }

            return View(orders);
        }

        [Authorize(Roles = "Client")]
        public IActionResult Payment(decimal totalPrice)
        {
            ViewBag.TotalPrice = totalPrice;
            return View();
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> Details(long orderId)
        {
            List<OrderDetail> orderDetails;
            try
            {
                orderDetails = await _dbContext.OrderDetails.Where(x => x.Order.Id == orderId)
                                                                .Include(x => x.Order)
                                                                .Include(x => x.Item)
                                                                .ToListAsync();

                decimal sum = orderDetails.Sum(x => x.Item.Price);

                ViewBag.Sum = sum;

                ViewBag.OrderId = orderId;
            }
            catch
            {
                orderDetails = new List<OrderDetail>();
            }

            return View(orderDetails);
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> CreateOrder(Payment paymentData)
        {
            try
            {
                var userId = User.Claims.ToList().Where(x => x.Type == "userId").Select(x => x.Value).SingleOrDefault();

                UserProfile user = await _dbContext.UserProfiles.Where(x => x.Id == long.Parse(userId)).SingleOrDefaultAsync();

                var cart = await _dbContext.Carts.Where(x => x.UserProfile.Id == long.Parse(userId))
                                                 .Include(x => x.UserProfile)
                                                 .Include(x => x.Item)
                                                 .ToListAsync();

                decimal sum = cart.Sum(x => x.Item.Price);

                Order order = new Order(user, sum);
                _dbContext.Orders.Add(order);
                await _dbContext.SaveChangesAsync();

                foreach (var item in cart)
                {
                    OrderDetail orderDetail = new OrderDetail(order, item.Item);
                    _dbContext.OrderDetails.Add(orderDetail);
                    _dbContext.Carts.Remove(item);
                }

                Payment payment = new Payment(paymentData.Name, $"xxxx-{paymentData.CardNumber.Substring(paymentData.CardNumber.Length - 3)}", paymentData.ExpirationMonth, paymentData.ExpirationYear, paymentData.Cvv, order);

                _dbContext.Payments.Add(payment);

                await _dbContext.SaveChangesAsync();

                TempData["Message"] = $"Order No. {order.Id} created successfully";

                return RedirectToAction("Index", "Order");
            }
            catch
            {
                return RedirectToAction("Index", "Cart");
            }
        }
    }
}
