﻿using CoffeeShop.Context;
using CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeShop.Controllers
{
    public class CartController : Controller
    {
        private readonly DBContext _dbContext;

        public CartController(DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> Index()
        {
            List<Cart> carts;
            try
            {
                var userId = User.Claims.ToList().Where(x => x.Type == "userId").Select(x => x.Value).SingleOrDefault();

                carts = await _dbContext.Carts.Where(x => x.UserProfile.Id == long.Parse(userId))
                                                 .Include(x => x.UserProfile)
                                                 .Include(x => x.Item)
                                                 .ToListAsync();

                ViewBag.Sum = carts.Sum(x => x.Item.Price);
            }
            catch
            {
                carts = new List<Cart>();
            }

            return View(carts);
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> DeleteItem(long cartId)
        {
            try
            {
                var cart = await _dbContext.Carts.Where(x => x.Id == cartId).SingleOrDefaultAsync();

                if (cart != null)
                {
                    _dbContext.Carts.Remove(cart);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch(Exception ex)
            {

            }
            return RedirectToAction("Index", "Cart");
        }

        [Authorize(Roles = "Client")]
        public async Task<IActionResult> Add(long itemId)
        {
            try
            {
                var userId = User.Claims.ToList().Where(x => x.Type == "userId").Select(x => x.Value).SingleOrDefault();
                var user = await _dbContext.UserProfiles.Where(x => x.Id == long.Parse(userId)).SingleOrDefaultAsync();
                var item = await _dbContext.Items.Where(x => x.Id == itemId).SingleOrDefaultAsync();

                Cart cart = new Cart(item, user);
                _dbContext.Carts.Add(cart);
                await _dbContext.SaveChangesAsync();
            }
            catch(Exception ex)
            {

            }

            return RedirectToAction("Index", "Menu");
        }
    }
}
