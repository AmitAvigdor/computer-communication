﻿using CoffeeShop.Context;
using CoffeeShop.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop.Controllers
{
    public class AuthController : Controller
    {
        private readonly DBContext _dbContext;

        public AuthController(DBContext dBContext)
        {
            _dbContext = dBContext;
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(UserProfile userprofile)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = await _dbContext.UserProfiles.Where(x => x.UserName == userprofile.UserName &&
                                                                         x.Password == userprofile.Password)
                                                             .SingleOrDefaultAsync();

                    if (user != null)
                    {
                        var userClaims = new List<Claim>()
                    {
                        new Claim(ClaimTypes.Name, user.UserName),
                        new Claim(ClaimTypes.Role, user.Role),
                        new Claim("userId", user.Id.ToString())
                    };

                        var identity = new ClaimsIdentity(userClaims, CookieAuthenticationDefaults.AuthenticationScheme);
                        var userPrincipal = new ClaimsPrincipal(new[] { identity });
                        await HttpContext.SignInAsync(userPrincipal);

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("Failure", "Wrong Username and password combination !");
                        return View();
                    }
                }
                else
                {
                    return View(userprofile);
                }
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("Failure", "Wrong Username and password combination !");
                return View();
            }
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
    }
}
