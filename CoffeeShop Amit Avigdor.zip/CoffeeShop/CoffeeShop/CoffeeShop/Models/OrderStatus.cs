﻿namespace CoffeeShop.Models
{
    public enum OrderStatus
    {
        New = 1,
        Preparing = 2,
        Ready = 4
    }
}
