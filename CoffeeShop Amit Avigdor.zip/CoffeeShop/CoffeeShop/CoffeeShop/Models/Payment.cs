﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("Payments", Schema = "Shop")]
    public class Payment
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string CardNumber { get; set; }
        public int ExpirationMonth { get; set; }
        public int ExpirationYear { get; set; }
        public int Cvv { get; set; }
        public Order Order { get; set; }

        public Payment()
        {

        }

        public Payment(string name, string cardNumber, int expirationMonth, int expirationYear, int cvv, Order order)
        {
            this.Name = name;
            this.CardNumber = cardNumber;
            this.ExpirationMonth = expirationMonth;
            this.ExpirationYear = expirationYear;
            this.Cvv = cvv;
            this.Order = order;
        }
    }
}
