﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("OrderDetails", Schema = "Shop")]
    public class OrderDetail
    {
        public long Id { get; set; }
        public Order Order { get; set; }
        public Item Item { get; set; }

        public OrderDetail()
        {

        }

        public OrderDetail(Order order, Item item)
        {
            this.Order = order;
            this.Item = item;
        }
    }
}
