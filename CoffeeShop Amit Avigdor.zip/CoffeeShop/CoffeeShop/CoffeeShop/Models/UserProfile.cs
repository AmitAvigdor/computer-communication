﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("UserProfiles", Schema = "Shop")]
    public class UserProfile
    {
        public long Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public string Role { get; set; }

        public UserProfile()
        {

        }
    }
}
