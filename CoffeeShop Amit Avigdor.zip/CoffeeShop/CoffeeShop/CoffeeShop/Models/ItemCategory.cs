﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("ItemsCategories", Schema = "Shop")]
    public class ItemCategory
    {
        public long Id { get; set; }
        public string Name { get; set; }

        public ItemCategory()
        {

        }

        public ItemCategory(string name)
        {
            this.Name = name;
        }
    }
}
