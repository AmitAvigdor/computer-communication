﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("Items", Schema = "Shop")]
    public class Item
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public ItemCategory Category { get; set; }
        public decimal Price { get; set; }
        public bool IsAvailable { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }

        public Item()
        {

        }

        public Item(string name, ItemCategory category, decimal price, string description, string image, bool isAvailable = true)
        {
            this.Name = name;
            this.Category = category;
            this.Price = price;
            this.IsAvailable = isAvailable;
            this.Description = description;
            this.Image = image;
        }
    }
}
