﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("Carts", Schema = "Shop")]
    public class Cart
    {
        public long Id { get; set; }
        public Item Item { get; set; }
        public UserProfile UserProfile { get; set; }

        public Cart()
        {

        }

        public Cart(Item item, UserProfile user)
        {
            this.Item = item;
            this.UserProfile = user;
        }
    }
}
