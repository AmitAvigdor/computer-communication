﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeShop.Models
{
    [Table("Orders", Schema = "Shop")]
    public class Order
    {
        public long Id { get; set; }
        public UserProfile User { get; set; }
        public decimal TotalPrice { get; set; }

        public OrderStatus OrderStatus { get; set; }

        public DateTime CreationDate { get; set; }

        public Order()
        {

        }

        public Order(UserProfile user, decimal totalPrice)
        {
            this.User = user;
            this.TotalPrice = totalPrice;
            this.OrderStatus = OrderStatus.New;
            this.CreationDate = DateTime.Now;
        }
    }
}
