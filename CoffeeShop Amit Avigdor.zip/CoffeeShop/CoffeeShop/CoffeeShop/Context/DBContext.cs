﻿using CoffeeShop.Models;
using Microsoft.EntityFrameworkCore;

namespace CoffeeShop.Context
{
    public class DBContext: DbContext
    {
        public DBContext(DbContextOptions<DBContext> options):base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Item>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<Payment>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<OrderDetail>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<Order>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<Cart>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<ItemCategory>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<UserProfile>()
                        .HasKey(a => new { a.Id });

            modelBuilder.Entity<Item>()
                .HasOne(a => a.Category);

            modelBuilder.Entity<Cart>()
                .HasOne(a => a.Item);

            modelBuilder.Entity<Cart>()
                .HasOne(a => a.UserProfile);

            modelBuilder.Entity<Order>()
                .HasOne(a => a.User);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(a => a.Order);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(a => a.Item);

            modelBuilder.Entity<Payment>()
                .HasOne(a => a.Order);

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Item> Items { get; set; }

        public DbSet<ItemCategory> ItemCategories { get; set; }

        public DbSet<UserProfile> UserProfiles { get; set; }

        public DbSet<Cart> Carts { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<OrderDetail> OrderDetails { get; set; }

        public DbSet<Payment> Payments { get; set; }
    }
}
